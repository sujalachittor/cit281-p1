/*
    CIT 281 Project 1
    Name: Sujala Chittor
*/
console.log((["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][(new Date()).getDay()]));